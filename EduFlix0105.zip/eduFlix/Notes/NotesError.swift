//
//  NotesError.swift
//  eduFlix
//
//  Created by Soreya Koura on 28.04.22.
//

import Foundation

enum NotesError: LocalizedError, Error {
    case saveNote
    
}
